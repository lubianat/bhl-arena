from flask import Blueprint, render_template, request, jsonify
from .services import get_or_fetch_files
from .models import File
from . import db
arena = Blueprint('arena', __name__)

@arena.route('/')
def index():
    file1, file2 = get_or_fetch_files()
    return render_template('arena.html', file1=file1, file2=file2)

@arena.route('/submit_choice', methods=['POST'])
def submit_choice():
    data = request.json
    winner_id = data.get('winner')
    loser_id = data.get('loser')

    winner = File.query.get(winner_id)
    loser = File.query.get(loser_id)

    if winner:
        winner.wins += 1
    if loser:
        loser.losses += 1
    if not winner and not loser:
        raise ValueError("Invalid file IDs provided.")

    db.session.commit()
    return jsonify({})

@arena.route('/rank')
def rank():
    # Retrieve all files ordered by wins descending
    files = File.query.order_by((File.wins - File.losses).desc()).all()    
    return render_template('rank.html', files=files)
