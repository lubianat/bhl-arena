import requests
from .models import File
from . import db
from sqlalchemy.sql import func  # Import func for SQLAlchemy functions


WIKIMEDIA_API = "https://commons.wikimedia.org/w/api.php"

def fetch_random_file_from_category(category):
    """
    Fetch a random file from a Wikimedia Commons category using 'Special:RandomInCategory'.
    """
    # 1) Let the server handle randomness by requesting the special page
    random_url = (
        f"https://commons.wikimedia.org/wiki/Special:RandomInCategory?wpcategory={category}"
    )
    response = requests.get(random_url)
    
    # 2) The request will follow redirects by default. The final URL is the random file page
    final_url = response.url
    print(f"Final URL after redirect: {final_url}")
    
    # If it didn't land on something in the File namespace, bail or handle accordingly
    # e.g. if it’s "Category:SomeCategory" or "Commons:Something", it's not a file
    if "?title=File:" not in final_url:
        print (
            f"Random result not a file page. Got URL: {final_url}"
        )
        return fetch_random_file_from_category(category)

    file_title = final_url.split("?title=File:")[-1].split("&")[0].replace("_", " ")
    if ".jpg" not in file_title:
        print(
            f"Random result not a JPG file. Got title: {file_title}"
        )
        return fetch_random_file_from_category(category)
    # Check if the file already exists in the database
    existing_file = File.query.filter_by(name=file_title).first()
    if existing_file:
        print(f"File already exists in database: {file_title}")
        return existing_file

    # Add new file to the database
    new_file = File(name=file_title)
    db.session.add(new_file)
    db.session.commit()
    print(f"New file added to database: {file_title}")
    return new_file

def get_or_fetch_files():
    """
    Always fetch new files from the Wikimedia category and populate the database.
    Ensures at least two files are returned.
    """
    # Ensure the database has two entries by always fetching new files
    while File.query.count() < 2:
        print(File.query.count())
        print("Fetching new files to ensure at least two entries in the database.")
        fetch_random_file_from_category("Files from the Biodiversity Heritage Library")

    # Always fetch new files from Wikimedia and add them to the database
    fetch_random_file_from_category("Files from the Biodiversity Heritage Library")
    fetch_random_file_from_category("Files from the Biodiversity Heritage Library")

    # Query the database for two random files
    files = File.query.order_by(func.random()).limit(2).all()
    return files[0], files[1]

